﻿using System;
using System.Windows;

namespace CheerfulGiverNXT
{
    //internal static class Program
    //{
    //    [STAThread]
    //    //public static void Main()
    //    //{
    //    //    var app = new Application();
    //    //    app.Run(new MainWindow());
    //    //}
    //}
}
