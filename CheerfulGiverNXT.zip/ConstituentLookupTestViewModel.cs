using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace CheerfulGiverNXT
{
    public sealed class ConstituentLookupTestViewModel : INotifyPropertyChanged
    {
        // UI bindings
        public AsyncRelayCommand LoginCommand { get; }
        public AsyncRelayCommand SearchCommand { get; }
        public RelayCommand CopySelectedIdCommand { get; }

        private CancellationTokenSource? _cts;

        private readonly BlackbaudMachineTokenProvider _tokenProvider;

        public ObservableCollection<RenxtConstituentLookupService.ConstituentGridRow> Results { get; } = new();

        public ConstituentLookupTestViewModel()
        {
            _tokenProvider = App.TokenProvider;

            LoginCommand = new AsyncRelayCommand(AuthorizeThisComputerAsync, () => IsNotBusy);
            SearchCommand = new AsyncRelayCommand(SearchAsync, () => IsNotBusy);
            CopySelectedIdCommand = new RelayCommand(CopySelectedId, () => HasSelection);

            MachineName = Environment.MachineName;
            AccessToken = "(not loaded)";
            SubscriptionKey = "(not loaded)";
        }

        private string _machineName = "";
        public string MachineName
        {
            get => _machineName;
            private set { _machineName = value; OnPropertyChanged(); }
        }

        private string _accessToken = "";
        /// <summary>
        /// Debug/visibility only. Not used for API calls (auth headers are injected by handler).
        /// </summary>
        public string AccessToken
        {
            get => _accessToken;
            private set { _accessToken = value; OnPropertyChanged(); }
        }

        private string _subscriptionKey = "";
        /// <summary>
        /// Debug/visibility only. Not used for API calls (key header is injected by handler).
        /// </summary>
        public string SubscriptionKey
        {
            get => _subscriptionKey;
            private set { _subscriptionKey = value; OnPropertyChanged(); }
        }

        private string _searchText = "";
        public string SearchText
        {
            get => _searchText;
            set { _searchText = value; OnPropertyChanged(); }
        }

        private string _statusText = "Ready.";
        public string StatusText
        {
            get => _statusText;
            set { _statusText = value; OnPropertyChanged(); }
        }

        private bool _isBusy;
        public bool IsBusy
        {
            get => _isBusy;
            private set
            {
                _isBusy = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(IsNotBusy));
                OnPropertyChanged(nameof(BusyVisibility));
            }
        }

        public bool IsNotBusy => !IsBusy;
        public Visibility BusyVisibility => IsBusy ? Visibility.Visible : Visibility.Collapsed;

        private RenxtConstituentLookupService.ConstituentGridRow? _selectedRow;
        public RenxtConstituentLookupService.ConstituentGridRow? SelectedRow
        {
            get => _selectedRow;
            set
            {
                _selectedRow = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(HasSelection));
                CopySelectedIdCommand.RaiseCanExecuteChanged();
            }
        }

        public bool HasSelection => SelectedRow is not null;

        // STEP 2: Authorize this computer (stores refresh token in SQL under MACHINE:<COMPUTERNAME>)
        private async Task AuthorizeThisComputerAsync()
        {
            IsBusy = true;
            StatusText = "Opening browser to authorize this computer...";
            LoginCommand.RaiseCanExecuteChanged();
            SearchCommand.RaiseCanExecuteChanged();

            try
            {
                const string redirectUri = "https://localhost:5001/auth/callback";
                const string scope = "rnxt.r";

                await _tokenProvider.SeedThisMachineAsync(redirectUri, scope).ConfigureAwait(false);

                // Load + show current values (for the debug expander)
                await LoadDebugAuthValuesAsync().ConfigureAwait(false);

                StatusText = $"Authorized for this computer ({Environment.MachineName}).";
            }
            catch (Exception ex)
            {
                StatusText = "Authorization error: " + ex.Message;
            }
            finally
            {
                IsBusy = false;
                LoginCommand.RaiseCanExecuteChanged();
                SearchCommand.RaiseCanExecuteChanged();
            }
        }

        private async Task SearchAsync()
        {
            var text = (SearchText ?? "").Trim();
            if (string.IsNullOrWhiteSpace(text))
            {
                StatusText = "Type a name or street number + street (e.g., \"1068 Lindsay\").";
                return;
            }

            _cts?.Cancel();
            _cts?.Dispose();
            _cts = new CancellationTokenSource();

            IsBusy = true;
            SearchCommand.RaiseCanExecuteChanged();
            StatusText = "Searching...";

            try
            {
                Results.Clear();

                // Ensure we have a valid token & key (and update debug fields).
                // API calls themselves use the shared HttpClient (headers injected by handler).
                await LoadDebugAuthValuesAsync(_cts.Token).ConfigureAwait(false);

                var rows = await App.ConstituentService.SearchGridAsync(text, _cts.Token).ConfigureAwait(false);

                foreach (var row in rows)
                    Results.Add(row);

                StatusText = rows.Count == 0 ? "No matches." : $"Found {rows.Count} match(es).";
            }
            catch (OperationCanceledException)
            {
                StatusText = "Search canceled.";
            }
            catch (InvalidOperationException ex)
            {
                StatusText = ex.Message;
                MessageBox.Show(ex.Message, "Not Authorized", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            catch (Exception ex)
            {
                StatusText = "Error: " + ex.Message;
                MessageBox.Show("Error during search:\n" + ex, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                IsBusy = false;
                SearchCommand.RaiseCanExecuteChanged();
            }
        }

        private async Task LoadDebugAuthValuesAsync(CancellationToken ct = default)
        {
            var (token, key) = await _tokenProvider.GetAsync(ct).ConfigureAwait(false);

            // Don't show the full token on-screen; show a preview.
            AccessToken = Preview(token, 18);
            SubscriptionKey = Preview(key, 10);
        }

        private static string Preview(string s, int take)
        {
            if (string.IsNullOrWhiteSpace(s)) return "(empty)";
            s = s.Trim();
            return s.Length <= take ? s : s.Substring(0, take) + "…";
        }

        private void CopySelectedId()
        {
            if (SelectedRow is null) return;
            Clipboard.SetText(SelectedRow.Id.ToString());
            StatusText = $"Copied Constituent ID {SelectedRow.Id} to clipboard.";
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string? name = null) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
